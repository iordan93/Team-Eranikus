﻿using System;

public interface IRenderable 
{
    void Render();
}