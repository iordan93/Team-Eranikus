﻿using System;

public class Human : IRenderable
{
    // Constructors, properties, and all that jazz :D
    public Human(int x, int y)
    {
        this.Position = new Position(x, y);
    }

    public Position Position { get; set; }

    public void Render()
    {
        this.Render(GetDefaultConsoleRenderSettings(this.Position));
    }

    public void Render(ConsoleRenderSettings settings)
    {
        var currentColor = Console.ForegroundColor;
        Console.ForegroundColor = settings.Color;
        Console.SetCursorPosition(settings.Position.X, settings.Position.Y);
        Console.Write(settings.Symbol);

        Console.ForegroundColor = currentColor;
    }

    private static ConsoleRenderSettings GetDefaultConsoleRenderSettings(Position position)
    {
        return new ConsoleRenderSettings(position, ConsoleColor.Yellow, 'o');
    }
}
