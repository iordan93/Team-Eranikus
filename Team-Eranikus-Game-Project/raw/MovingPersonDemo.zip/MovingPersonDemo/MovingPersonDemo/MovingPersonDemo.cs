﻿using System;
using System.Threading;

public class MovingPersonDemo
{
    private static int SleepTime = 50;

    public static void Main()
    {
        Console.BufferHeight = Console.WindowHeight;
        Console.CursorVisible = false;
        var human = new Human(4, 7);

        while (true)
        {
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey();

                if (key.Key == ConsoleKey.LeftArrow)
                {
                    // TODO: Validate position (instead of throwing an exception)
                    human.Position = new Position(human.Position.X - 1, human.Position.Y);
                }
                else if (key.Key == ConsoleKey.UpArrow)
                {
                    human.Position = new Position(human.Position.X, human.Position.Y - 1);
                }
                else if (key.Key == ConsoleKey.RightArrow)
                {
                    human.Position = new Position(human.Position.X + 1, human.Position.Y);
                }
                else if (key.Key == ConsoleKey.DownArrow)
                {
                    human.Position = new Position(human.Position.X, human.Position.Y + 1);
                }
            }

            // It is wrong to clear the whole console, it is here just for the purposes of this demo
            Console.Clear();
            human.Render();

            Thread.Sleep(SleepTime);
        }
    }
}