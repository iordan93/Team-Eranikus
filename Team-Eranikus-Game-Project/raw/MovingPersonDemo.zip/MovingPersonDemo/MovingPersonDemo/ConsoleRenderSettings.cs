﻿using System;

public class ConsoleRenderSettings
{
    public ConsoleRenderSettings(Position position, ConsoleColor color, char symbol)
    {
        this.Position = position;
        this.Color = color;
        this.Symbol = symbol;
    }

    public Position Position { get; set; }
    
    public ConsoleColor Color { get; set; }

    public char Symbol { get; set; }
}