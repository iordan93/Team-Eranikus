﻿using System;

public struct Position
{
    private int x;
    private int y;

    public Position(int x, int y)
        : this()
    {
        this.X = x;
        this.Y = y;
    }

    #region Properties
    public int X
    {
        get
        {
            return this.x;
        }
        set
        {
            if (value < 0 || value >= Console.WindowWidth)
            {
                throw new ArgumentException("The X coordinate of the position is invalid.");
            }

            this.x = value;
        }
    }

    public int Y
    {
        get
        {
            return this.y;
        }
        set
        {
            if (value < 0 || value >= Console.WindowHeight)
            {
                throw new ArgumentException("The Y coordinate of the position is invalid.");
            }

            this.y = value;
        }
    }
    #endregion
}